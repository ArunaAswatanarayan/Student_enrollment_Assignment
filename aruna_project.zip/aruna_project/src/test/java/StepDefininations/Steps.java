package StepDefininations;

import org.json.simple.JSONObject;
import org.testng.Assert;

import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class Steps {
	public RequestSpecification request;
	public JSONObject requestParams;
	public Response response;
@Given("I have given API URI {string} to register a student record")
public void i_have_given_api_uri_to_register_a_student_record(String URI) {
    // Write code here that turns the phrase above into concrete actions
	//Creating a Request which points to the base end point URI
	RestAssured.baseURI =URI;
	request = RestAssured.given();

}

@When("I set a requeste header to receive the data in JSON format")
public void i_set_a_requeste_header_to_receive_the_data_in_json_format() {
    // Write code here that turns the phrase above into concrete actions
	// setting request body to receive in JSON
	request.header("Content-Type", "application/json");

}

@When("I send a POST request with studentRecord as {int} {string} {string} {string} {string}")
public void i_send_a_post_request_with_student_record_as(Integer id, String firstname, String lastName, String class1, String nationality) {
    // Write code here that turns the phrase above into concrete actions
	//Create a JSONrequest instance to hold the data to be posted
	requestParams = new JSONObject();
	requestParams.put("id", id); 
	requestParams.put("firstName ", firstname);
	requestParams.put("lastName ", lastName);
	requestParams.put("class ", class1);
	requestParams.put("nationality ",  nationality);
	// sending the Post the request to register the student record and checking the response
	Response response = request.post("/register");
}

@Then("I should receive the response with success code {string}")
public void i_should_receive_the_response_with_success_code(String statusCode1) {
    // Write code here that turns the phrase above into concrete actions
	int statusCode = response.getStatusCode();
	Assert.assertEquals(statusCode, "200");
	String successCode = response.jsonPath().get("SuccessCode");
	Assert.assertEquals( "Correct Success code was returned", successCode, "OPERATION_SUCCESS");
}

@Given("I have the API URI {string}")
public void i_have_the_api_uri(String URI) {
    // Write code here that turns the phrase above into concrete actions
	RestAssured.baseURI =URI;
	request = RestAssured.given();
}

@When("I send the PUT request  update record class {string} based on id {int}")
public void i_send_the_put_request_update_record_class_based_on_id(String classtype, int id) {
    // Write code here that turns the phrase above into concrete actions
	requestParams = new JSONObject();
	requestParams.put("id ", id); // Cast
	requestParams.put("class ", classtype);
	response = request.put("/update/"+ id);
}

@Then("I verify the response status code as {int} in step")
public void i_verify_the_response_status_code_as_in_step(int statusCode) {
    // Write code here that turns the phrase above into concrete actions
	int statusCode1 = response.getStatusCode();
	Assert.assertEquals(statusCode1, "200");
	String successCode = response.jsonPath().get("SuccessCode");
	Assert.assertEquals( "Correct Success code was returned", successCode, "OPERATION_SUCCESS");
}

@When("I send the DELETE request  to delete  record based on id {int}")
public void i_send_the_delete_request_to_delete_record_based_on_id(int idnum) {
    // Write code here that turns the phrase above into concrete actions
	response = request.delete("/delete/"+"id"+"/"+idnum);
}

@When("I send the GET request  to fetch  record based on class record {string}")
public void i_send_the_get_request_to_fetch_record_based_on_class_record(String ClassType) {
    // Write code here that turns the phrase above into concrete actions
	response = request.get("/class=" +ClassType);
}
	@When("I send the GET request  to fetch  record based on id {int}")
	public void i_send_the_get_request_to_fetch_record_based_on_id(int id) {
	    // Write code here that turns the phrase above into concrete actions
		response = request.get("/id" +id);

}
}
