package StepDefininations;
import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;
//import io.cucumber.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = ".//Features/register.feature",
glue = {"StepDefininations"}, 
monochrome = true, 
plugin = { "pretty",  "html:Reports/cucumber-pretty" })

public class TestRunner extends AbstractTestNGCucumberTests {   

}


